/**
 * Theme: Metrica - Responsive Bootstrap 4 Admin Dashboard
 * Author: Mannatthemes
 * Validation Js
 */


$(document).ready(function() {
    $('.form-parsley').parsley();
});